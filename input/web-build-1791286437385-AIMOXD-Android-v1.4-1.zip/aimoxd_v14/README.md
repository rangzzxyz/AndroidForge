# AIMOXD Android v1.4

Native Android floating assistant.

## Important behavior
- No embedded Chrome/browser window.
- AIMOXD itself is the floating robot overlay.
- The robot can stay above other apps after overlay permission is granted.
- MediaProjection is requested for screen analysis.
- DRAW lets the user circle an area on the current screen.
- ML Kit OCR reads text from the selected area.
- OCR text is sent to the configured real AI endpoint.
- The previous local visual-simulation result has been removed.
- The floating service can be stopped with the close button or notification.

## AI endpoint
Default endpoint:
https://sylvatica.my.id/api/ai/chatgpt?prompt=&chat_id=&auth=&apikey=

The API key is entered by the user in AIMOXD AI CONFIG and is not hard-coded.
