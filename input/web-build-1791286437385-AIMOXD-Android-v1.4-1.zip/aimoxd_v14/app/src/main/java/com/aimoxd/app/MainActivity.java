package com.aimoxd.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;
        private static final int OVERLAY_REQ = 1201;
    private static final int CAPTURE_REQ = 1203;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(0xFF05005C);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "AndroidAIMOXD");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1202);
    }

    public class Bridge {
        @JavascriptInterface public void requestFloating(String url) {
            runOnUiThread(() -> {
                if (Settings.canDrawOverlays(MainActivity.this)) { requestScreenCapture(); return; }
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Izin Jendela Mengambang")
                    .setMessage("AIMOXD membutuhkan izin tampil di atas aplikasi lain agar robot dapat digunakan di atas Chrome atau aplikasi lain.")
                    .setNegativeButton("BATAL", null)
                    .setPositiveButton("BERI IZIN", (d,w) -> {
                        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                        startActivityForResult(i, OVERLAY_REQ);
                    }).show();
            });
        }
        @JavascriptInterface public void closeFloating() { stopService(new Intent(MainActivity.this, FloatingRobotService.class)); }
    }

    private String normalize(String u) {
        if (u == null || u.trim().isEmpty()) return "https://example.com";
        u=u.trim(); return u.matches("(?i)^https?://.*")?u:"https://"+u;
    }

    private void requestScreenCapture() {
        new AlertDialog.Builder(this)
            .setTitle("Izin Analisis Layar")
            .setMessage("AIMOXD perlu izin tangkapan layar agar area yang kamu lingkari dapat dibaca. Teks dari area tersebut kemudian dikirim ke AI yang kamu konfigurasi untuk dianalisis.")
            .setNegativeButton("NANTI", (d,w) -> startFloating(false))
            .setPositiveButton("IZINKAN", (d,w) -> {
                MediaProjectionManager mpm = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
                startActivityForResult(mpm.createScreenCaptureIntent(), CAPTURE_REQ);
            }).show();
    }

    private void startFloating(boolean withCapture) {
        Intent s = new Intent(this, FloatingRobotService.class);
        if (withCapture) {
            s.putExtra("resultCode", getIntent().getIntExtra("captureResultCode", Activity.RESULT_CANCELED));
            Intent data = getIntent().getParcelableExtra("captureData");
            if (data != null) s.putExtra("captureData", data);
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
        Toast.makeText(this, "AIMOXD floating aktif. Sekarang kamu bisa berpindah aplikasi.", Toast.LENGTH_SHORT).show();
    }

    private void startFloatingWithCapture(int resultCode, Intent data) {
        Intent s = new Intent(this, FloatingRobotService.class)
                .putExtra("resultCode", resultCode).putExtra("captureData", data);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
    }

    @Override protected void onActivityResult(int r,int c,Intent d) {
        super.onActivityResult(r,c,d);
        if(r==OVERLAY_REQ && Settings.canDrawOverlays(this)) requestScreenCapture();
        else if(r==CAPTURE_REQ) {
            if(c==RESULT_OK && d!=null) startFloatingWithCapture(c,d);
            else startFloating(false);
        }
    }
}
