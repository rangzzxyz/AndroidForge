package com.aimoxd.app;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import java.nio.ByteBuffer;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

public class FloatingRobotService extends Service {
    private WindowManager wm; private FrameLayout root; private WindowManager.LayoutParams lp;
    private float downX, downY; private int startX, startY;
    private boolean drawing=false;
    private MediaProjection projection; private ImageReader reader; private VirtualDisplay display; private Bitmap latest;
    private WindowManager drawWm; private DrawView drawOverlay; private WindowManager.LayoutParams drawLp;
    private int captureW, captureH;
    private AlertDialog aiProgress;

    @Override public void onCreate() { super.onCreate(); createChannel(); if(Build.VERSION.SDK_INT>=29) startForeground(7, notification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE); else startForeground(7, notification()); }

    private void createChannel(){ if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel("aimoxd_float","AIMOXD Floating",NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager.class).createNotificationChannel(c); } }
    private Notification notification(){ Intent i=new Intent(this,MainActivity.class); PendingIntent p=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT); Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"aimoxd_float"):new Notification.Builder(this); return b.setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("AIMOXD Floating aktif").setContentText("Robot siap menganalisis area yang kamu lingkari").setContentIntent(p).setOngoing(true).build(); }

    private TextView tv(String text,int size){ TextView v=new TextView(this); v.setText(text); v.setTextColor(Color.WHITE); v.setTextSize(size); v.setGravity(Gravity.CENTER); return v; }

    private void showRobot(){
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        root=new FrameLayout(this);
        GradientDrawable bg=new GradientDrawable(); bg.setColor(Color.argb(238,8,11,92)); bg.setCornerRadius(34); bg.setStroke(2,Color.rgb(0,207,255)); root.setBackground(bg);
        LinearLayout panel=new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setGravity(Gravity.CENTER); panel.setPadding(12,8,12,8);
        TextView bot=tv("AIMOXD\n◉",15); bot.setTypeface(null,1); panel.addView(bot,new LinearLayout.LayoutParams(94,84));
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER);
        Button draw=new Button(this); draw.setText("DRAW"); Button analyze=new Button(this); analyze.setText("ANALYZE"); Button close=new Button(this); close.setText("×");
        row.addView(draw,new LinearLayout.LayoutParams(72,46)); row.addView(analyze,new LinearLayout.LayoutParams(86,46)); row.addView(close,new LinearLayout.LayoutParams(55,46)); panel.addView(row);
        root.addView(panel,new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER));
        draw.setOnClickListener(v -> { drawing=!drawing; draw.setText(drawing?"CLEAR":"DRAW"); if(drawing) showDrawOverlay(); else hideDrawOverlay(); });
        analyze.setOnClickListener(v -> analyzeSelection());
        close.setOnClickListener(v -> stopSelf());
        panel.setOnTouchListener((v,e)->move(e));
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        lp=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,-3);
        lp.gravity=Gravity.TOP|Gravity.END; lp.x=18;lp.y=220; wm.addView(root,lp);
    }

    private boolean move(MotionEvent e){
        if(drawing) return false;
        if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getRawX();downY=e.getRawY();startX=lp.x;startY=lp.y;return true;}
        if(e.getAction()==MotionEvent.ACTION_MOVE){lp.x=startX+(int)(e.getRawX()-downX);lp.y=startY+(int)(e.getRawY()-downY);wm.updateViewLayout(root,lp);return true;}
        return e.getAction()==MotionEvent.ACTION_UP;
    }

    private void showDrawOverlay(){
        if(drawOverlay!=null) return;
        drawWm=(WindowManager)getSystemService(WINDOW_SERVICE);
        drawOverlay=new DrawView(this);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        drawLp=new WindowManager.LayoutParams(-1,-1,type,WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS|WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,-3);
        drawLp.gravity=Gravity.TOP|Gravity.START;
        drawWm.addView(drawOverlay,drawLp);
        Toast.makeText(this,"Lingkari area layar yang ingin dianalisis.",Toast.LENGTH_SHORT).show();
    }
    private void hideDrawOverlay(){
        if(drawWm!=null&&drawOverlay!=null){ try{drawWm.removeView(drawOverlay);}catch(Exception ignored){} }
        drawOverlay=null;
    }

    private void setupProjection(Intent data,int resultCode){
        try{
            MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection=m.getMediaProjection(resultCode,data);
            if(projection==null)return;
            DisplayMetricsCompat dm=new DisplayMetricsCompat(this); captureW=dm.w; captureH=dm.h;
            reader=ImageReader.newInstance(captureW,captureH,PixelFormat.RGBA_8888,2);
            reader.setOnImageAvailableListener(r->{ Image img=null; try{ img=r.acquireLatestImage(); if(img==null)return; Image.Plane p=img.getPlanes()[0]; ByteBuffer buf=p.getBuffer(); int rowStride=p.getRowStride(), pixelStride=p.getPixelStride(); Bitmap b=Bitmap.createBitmap(captureW,captureH,Bitmap.Config.ARGB_8888); byte[] row=new byte[rowStride]; int[] pixels=new int[captureW*captureH]; for(int y=0;y<captureH;y++){buf.position(Math.min(buf.capacity(),y*rowStride)); int need=Math.min(row.length,buf.remaining()); buf.get(row,0,need); for(int x=0;x<captureW;x++){int off=x*pixelStride; if(off+3<need){int rr=row[off]&255,gg=row[off+1]&255,bb=row[off+2]&255,aa=row[off+3]&255; pixels[y*captureW+x]=Color.argb(aa,rr,gg,bb);}}} b.setPixels(pixels,0,captureW,0,0,captureW,captureH); if(latest!=null)latest.recycle(); latest=b; }catch(Exception ignored){} finally{if(img!=null)img.close();}},new Handler(Looper.getMainLooper()));
            display=projection.createVirtualDisplay("AIMOXD-Capture",captureW,captureH,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,null);
        }catch(Exception e){ Toast.makeText(this,"Screen capture gagal: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private void analyzeSelection(){
        RectF sel=drawOverlay==null?null:drawOverlay.getSelection();
        if(sel==null){Toast.makeText(this,"Lingkari dulu area yang ingin dianalisis.",Toast.LENGTH_SHORT).show();return;}
        if(latest==null){Toast.makeText(this,"Menunggu frame layar. Coba lagi sebentar.",Toast.LENGTH_SHORT).show();return;}
        // The overlay is only a visual selector. Map its bounds to the captured screen using display size.
        int left=Math.max(0,(int)(sel.left/Math.max(1f,drawOverlay.getWidth())*latest.getWidth()));
        int top=Math.max(0,(int)(sel.top/Math.max(1f,drawOverlay.getHeight())*latest.getHeight()));
        int right=Math.min(latest.getWidth(),Math.max(left+1,(int)(sel.right/Math.max(1f,drawOverlay.getWidth())*latest.getWidth())));
        int bottom=Math.min(latest.getHeight(),Math.max(top+1,(int)(sel.bottom/Math.max(1f,drawOverlay.getHeight())*latest.getHeight())));
        Bitmap crop=Bitmap.createBitmap(latest,left,top,right-left,bottom-top);
        int[] px=new int[crop.getWidth()*crop.getHeight()]; crop.getPixels(px,0,crop.getWidth(),0,0,crop.getWidth(),crop.getHeight());
        InputImage image=InputImage.fromBitmap(crop,0);
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
            .addOnSuccessListener(result -> {
                String text=result.getText().trim();
                if(text.isEmpty()){
                    Toast.makeText(this,"Tidak ada teks yang terbaca. Coba lingkari soal dengan lebih jelas.",Toast.LENGTH_LONG).show();
                    return;
                }
                // OCR hanya mengambil teks dari area yang dipilih. Jawaban/penilaian dilakukan oleh endpoint AI sungguhan.
                askAi(text);
            })
            .addOnFailureListener(e -> Toast.makeText(this,"OCR gagal membaca area: "+e.getMessage(),Toast.LENGTH_LONG).show());
    }

    private void askAi(String extracted) {
        if (extracted == null || extracted.trim().isEmpty()) {
            Toast.makeText(this,"Tidak ada teks untuk dikirim ke AI.",Toast.LENGTH_SHORT).show();
            return;
        }
        android.content.SharedPreferences sp=getSharedPreferences("aimoxd_ai",MODE_PRIVATE);
        String key=sp.getString("api_key","");
        String endpoint=sp.getString("endpoint",AiEngine.DEFAULT_ENDPOINT);
        String chatId=sp.getString("chat_id","");
        String auth=sp.getString("auth","");
        if(key.trim().isEmpty()) { showAiSettings(extracted); return; }
        showAiProgress();
        new Thread(() -> {
            AiEngine.Result result;
            try { String prompt = "Kamu adalah AIMOXD AI. Analisis teks yang dibaca dari layar berikut. Jika ini soal, berikan jawaban yang benar dan penjelasan singkat. Jangan mengaku sebagai simulasi lokal.\n\nTEKS LAYAR:\n" + extracted;
                result=AiEngine.ask(endpoint, key, chatId, auth, prompt);
                getSharedPreferences("aimoxd_ai",MODE_PRIVATE).edit().putString("chat_id",result.chatId).putString("auth",result.auth).apply();
            } catch(Exception e) { result=new AiEngine.Result("AI tidak dapat dihubungi: "+e.getMessage(), chatId, auth); }
            final String out=result.response;
            new Handler(Looper.getMainLooper()).post(() -> showAiResult(out));
        }).start();
    }

    private void showAiSettings(String retryText) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(30,10,30,0);
        android.content.SharedPreferences sp=getSharedPreferences("aimoxd_ai",MODE_PRIVATE);
        EditText ep=new EditText(this); ep.setHint("API endpoint"); ep.setSingleLine(true); ep.setText(sp.getString("endpoint",AiEngine.DEFAULT_ENDPOINT));
        EditText key=new EditText(this); key.setHint("API key / apikey"); key.setSingleLine(true); key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); key.setText(sp.getString("api_key",""));
        EditText cid=new EditText(this); cid.setHint("Chat ID (optional)"); cid.setSingleLine(true); cid.setText(sp.getString("chat_id",""));
        box.addView(ep); box.addView(key); box.addView(cid);
        new AlertDialog.Builder(this).setTitle("AIMOXD AI CONFIG")
            .setMessage("AIMOXD memakai endpoint AI yang kamu konfigurasi. API key diisi sendiri dan tidak ditanam ke APK.")
            .setView(box).setNegativeButton("BATAL",null)
            .setPositiveButton("SIMPAN & TANYA",(d,w)->{ getSharedPreferences("aimoxd_ai",MODE_PRIVATE).edit().putString("endpoint",ep.getText().toString().trim()).putString("api_key",key.getText().toString().trim()).putString("chat_id",cid.getText().toString().trim()).apply(); askAi(retryText); }).show();
    }

    private void showAiProgress(){ aiProgress=new AlertDialog.Builder(this).setTitle("AIMOXD AI").setMessage("Menganalisis teks yang dipilih…").setCancelable(false).create(); aiProgress.show(); }
    private void showAiResult(String out){
        if(aiProgress!=null){try{aiProgress.dismiss();}catch(Exception ignored){} aiProgress=null;}
        new AlertDialog.Builder(this).setTitle("AIMOXD AI RESULT").setMessage(out).setPositiveButton("OK",null).show();
    }

    @Override public int onStartCommand(Intent i,int f,int id){
        if(root==null) showRobot();
        if(i!=null && i.hasExtra("captureData")){
            Intent d=i.getParcelableExtra("captureData");
            if(Build.VERSION.SDK_INT>=29) startForeground(7,notification(),android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE | android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            setupProjection(d,i.getIntExtra("resultCode",Activity.RESULT_CANCELED));
        }
        return START_STICKY;
    }
    @Override public void onDestroy(){ if(display!=null)display.release(); if(reader!=null)reader.close(); if(projection!=null)projection.stop(); if(latest!=null)latest.recycle(); if(drawWm!=null&&drawOverlay!=null) try{drawWm.removeView(drawOverlay);}catch(Exception ignored){} if(wm!=null&&root!=null) try{wm.removeView(root);}catch(Exception ignored){} super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent i){return null;}

    private class DrawView extends View{
        Paint p=new Paint(3); Path path=new Path(); float minX,minY,maxX,maxY; boolean has;
        DrawView(Context c){super(c);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(7);p.setColor(Color.CYAN);p.setStrokeCap(Paint.Cap.ROUND);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        protected void onDraw(Canvas c){super.onDraw(c); if(has){c.drawPath(path,p);}}
        public boolean onTouchEvent(MotionEvent e){float x=e.getX(),y=e.getY(); if(e.getAction()==MotionEvent.ACTION_DOWN){path.reset();path.moveTo(x,y);minX=maxX=x;minY=maxY=y;has=true;invalidate();return true;} if(e.getAction()==MotionEvent.ACTION_MOVE){path.lineTo(x,y);minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);invalidate();return true;} if(e.getAction()==MotionEvent.ACTION_UP){path.close();invalidate();postDelayed(()->{ if(has){ analyzeSelection(); hideDrawOverlay(); drawing=false; } },250);return true;} return true;}
        void clear(){path.reset();has=false;invalidate();}
        RectF getSelection(){return has?new RectF(minX,minY,maxX,maxY):null;}
    }

    static class DisplayMetricsCompat { int w,h,densityDpi; DisplayMetricsCompat(Context c){android.util.DisplayMetrics d=c.getResources().getDisplayMetrics();w=d.widthPixels;h=d.heightPixels;densityDpi=d.densityDpi;} }
}
