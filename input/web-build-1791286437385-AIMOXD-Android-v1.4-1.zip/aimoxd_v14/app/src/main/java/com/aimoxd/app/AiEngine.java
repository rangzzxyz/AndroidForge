package com.aimoxd.app;

import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/** Client for the user's supplied Sylvatica ChatGPT endpoint. */
public final class AiEngine {
    private AiEngine() {}

    public static final String DEFAULT_ENDPOINT =
            "https://sylvatica.my.id/api/ai/chatgpt?prompt=&chat_id=&auth=&apikey=";

    public static Result ask(String endpoint, String apiKey, String chatId, String auth, String prompt) throws Exception {
        if (endpoint == null || endpoint.trim().isEmpty()) endpoint = DEFAULT_ENDPOINT;
        String base = endpoint.trim();
        int q = base.indexOf('?');
        if (q >= 0) base = base.substring(0, q);

        StringBuilder urlText = new StringBuilder(base).append('?');
        urlText.append("prompt=").append(enc(prompt == null ? "" : prompt));
        urlText.append("&chat_id=").append(enc(chatId == null ? "" : chatId));
        urlText.append("&auth=").append(enc(auth == null ? "" : auth));
        urlText.append("&apikey=").append(enc(apiKey == null ? "" : apiKey));

        HttpURLConnection c = (HttpURLConnection)new URL(urlText.toString()).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(15000);
        c.setReadTimeout(45000);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("User-Agent", "AIMOXD-Android/1.3");

        int code = c.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String raw = read(is);
        if (code < 200 || code >= 300) throw new IOException("HTTP " + code + ": " + raw);

        JSONObject root = new JSONObject(raw);
        JSONObject result = root.optJSONObject("result");
        if (result == null) throw new IOException("Format respons API tidak dikenali.");

        String response = result.optString("response", "");
        if (response.trim().isEmpty()) response = "API tidak mengembalikan jawaban.";
        return new Result(response, result.optString("chat_id", chatId == null ? "" : chatId),
                result.optString("auth", auth == null ? "" : auth));
    }

    private static String enc(String s) throws Exception {
        return URLEncoder.encode(s, StandardCharsets.UTF_8.name());
    }

    private static String read(InputStream in) throws Exception {
        if (in == null) return "";
        BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder s = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) s.append(line);
        return s.toString();
    }

    public static final class Result {
        public final String response;
        public final String chatId;
        public final String auth;
        Result(String response, String chatId, String auth) {
            this.response = response;
            this.chatId = chatId;
            this.auth = auth;
        }
    }
}
