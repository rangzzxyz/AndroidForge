# AIMOXD Native Full AI

Native Android AIMOXD build containing:
- AIMOXD native UI
- Floating bot overlay
- MediaProjection screen capture
- ML Kit OCR of the captured screen
- Real HTTP call to the supplied AI endpoint
- API key input (not hard-coded)
- Persistent chat_id/auth from the API response
- Last AI response viewer
- No Chrome/iframe/Quick Launch simulation

Default endpoint:
https://sylvatica.my.id/api/ai/chatgpt?prompt=&chat_id=&auth=&apikey=

AndroidForge:
1. Upload this ZIP.
2. Select `release`.
3. Force-install NDK OFF.
4. Build APK.

The AI request sends the captured screen's OCR text in `prompt`. The current endpoint contract supplied in the conversation is text/query based, so this build does not claim to send the raw screenshot as an image. No private token/cookie is embedded.
