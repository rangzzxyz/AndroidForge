package com.aimoxd.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class SelectionActivity extends Activity {
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        FrameLayout f=new FrameLayout(this);
        f.setBackgroundColor(Color.argb(70,0,0,0));
        TextView t=new TextView(this); t.setText("AIMOXD\nDrag to select an area"); t.setTextColor(Color.WHITE); t.setTextSize(18); t.setGravity(17);
        f.addView(t,new FrameLayout.LayoutParams(-1,-1));
        setContentView(f);
    }
}
