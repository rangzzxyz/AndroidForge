package com.aimoxd.app;

import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.ImageView;

public class FloatingService extends Service {
    WindowManager wm; ImageView bot;
    @Override public void onCreate(){
        super.onCreate(); channel(); startForeground(7001,note());
        if(Settings.canDrawOverlays(this)) show();
    }
    void show(){
        wm=(WindowManager)getSystemService(WINDOW_SERVICE); bot=new ImageView(this);
        bot.setImageResource(R.drawable.aimoxd_bot); bot.setPadding(8,8,8,8);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(84,84,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.END;p.x=18;p.y=180;
        bot.setOnClickListener(v->{Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);});
        wm.addView(bot,p);
    }
    Notification note(){return new Notification.Builder(this,"aimoxd").setContentTitle("AIMOXD").setContentText("Floating assistant aktif").setSmallIcon(android.R.drawable.ic_dialog_info).setOngoing(true).build();}
    void channel(){if(Build.VERSION.SDK_INT>=26)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel("aimoxd","AIMOXD",NotificationManager.IMPORTANCE_LOW));}
    @Override public void onDestroy(){if(wm!=null&&bot!=null)try{wm.removeView(bot);}catch(Exception e){}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
