package com.aimoxd.app;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.content.pm.ServiceInfo;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.net.URLEncoder;
import java.util.concurrent.*;

public class CaptureService extends Service {
    static final String R="result",D="data",P="prompt",K="key",E="endpoint";
    MediaProjection projection; ImageReader reader; Handler handler; String prompt,key,endpoint; boolean done=false;

    public static void start(Context c,int result,Intent data,String prompt,String key,String endpoint){
        Intent i=new Intent(c,CaptureService.class); i.putExtra(R,result);i.putExtra(D,data);i.putExtra(P,prompt);i.putExtra(K,key);i.putExtra(E,endpoint);
        if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i);else c.startService(i);
    }
    @Override public int onStartCommand(Intent in,int flags,int id){
        channel(); Notification n=new Notification.Builder(this,"capture").setContentTitle("AIMOXD AI").setContentText("Reading screen…").setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build();
        if(Build.VERSION.SDK_INT>=29)startForeground(7002,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);else startForeground(7002,n);
        prompt=in.getStringExtra(P);key=in.getStringExtra(K);endpoint=in.getStringExtra(E);
        int result=in.getIntExtra(R,0); Intent data=in.getParcelableExtra(D);
        MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE); projection=m.getMediaProjection(result,data);
        DisplayMetrics dm=getResources().getDisplayMetrics(); int w=dm.widthPixels,h=dm.heightPixels;
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2); handler=new Handler(Looper.getMainLooper());
        projection.createVirtualDisplay("AIMOXD",w,h,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
        reader.setOnImageAvailableListener(x->{if(done)return; Image im=null;try{im=x.acquireLatestImage();if(im!=null){done=true; Bitmap bm=bitmap(im,w,h); analyze(bm);}}catch(Exception e){stopSelf();}finally{if(im!=null)im.close();}},handler);
        return START_NOT_STICKY;
    }
    Bitmap bitmap(Image im,int w,int h){
        Image.Plane p=im.getPlanes()[0];ByteBufferHolder holder=new ByteBufferHolder(p.getBuffer());
        Bitmap b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);b.copyPixelsFromBuffer(holder.buffer);return b;
    }
    static class ByteBufferHolder{java.nio.ByteBuffer buffer;ByteBufferHolder(java.nio.ByteBuffer b){buffer=b;}}
    void analyze(Bitmap b){
        InputImage image=InputImage.fromBitmap(b,0);
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image).addOnSuccessListener(r->{
            String text=r.getText();
            if(text==null)text="";
            String user=prompt==null?"Analisis layar.":prompt;
            String full=user+"\n\nOCR dari layar:\n"+text;
            ask(full);
        }).addOnFailureListener(e->ask((prompt==null?"Analisis layar.":prompt)+"\nOCR gagal: "+e.getMessage()));
    }
    void ask(String p){
        new Thread(()->{
            try{
                String base=endpoint==null||endpoint.trim().isEmpty()?"https://sylvatica.my.id/api/ai/chatgpt?prompt=&chat_id=&auth=&apikey=":endpoint.trim();
                String chatId=getSharedPreferences("aimoxd",0).getString("chat_id","");
                String auth=getSharedPreferences("aimoxd",0).getString("auth","");
                String url=setParam(base,"prompt",URLEncoder.encode(p,"UTF-8"));
                url=setParam(url,"chat_id",URLEncoder.encode(chatId,"UTF-8"));
                url=setParam(url,"auth",URLEncoder.encode(auth,"UTF-8"));
                url=setParam(url,"apikey",URLEncoder.encode(key==null?"":key,"UTF-8"));
                HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
                c.setRequestMethod("GET");c.setConnectTimeout(15000);c.setReadTimeout(30000);c.setRequestProperty("Accept","application/json");
                int code=c.getResponseCode();InputStream is=code>=200&&code<400?c.getInputStream():c.getErrorStream();
                String body=read(is);
                JSONObject j=new JSONObject(body);JSONObject res=j.optJSONObject("result");
                String answer=res!=null?res.optString("response",body):j.optString("response",body);
                android.content.SharedPreferences.Editor ed=getSharedPreferences("aimoxd",0).edit().putString("last_response",answer);
                if(res!=null){
                    String newChat=res.optString("chat_id","");
                    String newAuth=res.optString("auth","");
                    if(!newChat.isEmpty()) ed.putString("chat_id",newChat);
                    if(!newAuth.isEmpty()) ed.putString("auth",newAuth);
                }
                ed.apply();
            }catch(Exception e){getSharedPreferences("aimoxd",0).edit().putString("last_response","API error: "+e.getMessage()).apply();}
            finally{stopSelf();}
        }).start();
    }
    String read(InputStream in)throws Exception{BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l);return s.toString();}
    void channel(){if(Build.VERSION.SDK_INT>=26)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel("capture","AIMOXD AI",NotificationManager.IMPORTANCE_LOW));}
    @Override public void onDestroy(){if(reader!=null)reader.close();if(projection!=null)projection.stop();super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
    static String setParam(String base,String key,String value){
        String encodedKey=key+"=";
        String pattern="([?&])"+java.util.regex.Pattern.quote(key)+"=[^&]*";
        if(base.matches(".*"+pattern+".*"))
            return base.replaceFirst(pattern,"$1"+encodedKey+value);
        return base+(base.contains("?")?"&":"?")+encodedKey+value;
    }
}
