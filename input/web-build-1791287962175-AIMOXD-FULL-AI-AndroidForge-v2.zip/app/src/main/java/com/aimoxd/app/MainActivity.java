package com.aimoxd.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final int CAPTURE=9001;
    static final int SELECT=9002;
    EditText prompt, apiKey, endpoint;
    TextView status;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        build();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 88);
    }

    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackgroundColor(Color.rgb(44,34,95)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,62);
        p.setMargins(0,10,0,0); b.setLayoutParams(p); return b; }

    void build(){
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setPadding(28,30,28,28);
        r.setBackgroundColor(Color.rgb(7,9,20));
        TextView t=new TextView(this); t.setText("AIMOXD"); t.setTextColor(Color.WHITE); t.setTextSize(34); t.setGravity(17); r.addView(t,new LinearLayout.LayoutParams(-1,70));
        TextView s=new TextView(this); s.setText("AI TASK ASSISTANT • NATIVE"); s.setTextColor(Color.rgb(146,153,181)); s.setGravity(17); r.addView(s,new LinearLayout.LayoutParams(-1,45));

        apiKey=new EditText(this); apiKey.setHint("API key (optional if endpoint does not require it)"); apiKey.setTextColor(Color.WHITE); apiKey.setHintTextColor(Color.GRAY); r.addView(apiKey);
        endpoint=new EditText(this); endpoint.setText("https://sylvatica.my.id/api/ai/chatgpt?prompt=&chat_id=&auth=&apikey="); endpoint.setTextColor(Color.WHITE); endpoint.setTextSize(12); r.addView(endpoint);
        prompt=new EditText(this); prompt.setHint("Tulis perintah untuk AIMOXD, contoh: Jelaskan teks di layar"); prompt.setTextColor(Color.WHITE); prompt.setHintTextColor(Color.GRAY); r.addView(prompt);

        Button overlay=btn("GRANT FLOATING OVERLAY"); r.addView(overlay); overlay.setOnClickListener(v->overlay());
        Button start=btn("START FLOATING AIMOXD"); r.addView(start); start.setOnClickListener(v->startFloat());
        Button analyze=btn("CAPTURE + OCR + ASK AI"); r.addView(analyze); analyze.setOnClickListener(v->capture());
        Button stop=btn("STOP AIMOXD"); r.addView(stop); stop.setOnClickListener(v->stopService(new Intent(this,FloatingService.class)));
        Button result=btn("SHOW LAST AI RESPONSE"); r.addView(result); result.setOnClickListener(v->showLast());

        status=new TextView(this); status.setTextColor(Color.rgb(146,153,181)); status.setPadding(0,18,0,0); r.addView(status);
        setContentView(r);
    }

    void overlay(){ startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); }
    void startFloat(){ if(!Settings.canDrawOverlays(this)){overlay();return;} Intent i=new Intent(this,FloatingService.class); if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i); }
    void capture(){
        if(prompt.getText().toString().trim().isEmpty()) { prompt.setText("Analisis isi layar ini dan jelaskan apa yang terlihat."); }
        MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(),CAPTURE);
    }

    void showLast(){
        String s=getSharedPreferences("aimoxd",0).getString("last_response","Belum ada respons AI.");
        new AlertDialog.Builder(this).setTitle("AIMOXD AI").setMessage(s).setPositiveButton("OK",null).show();
    }

    @Override protected void onActivityResult(int rc,int result,Intent data){
        super.onActivityResult(rc,result,data);
        if(rc==CAPTURE && result==RESULT_OK && data!=null){
            CaptureService.start(this,result,data,prompt.getText().toString(),apiKey.getText().toString(),endpoint.getText().toString());
            status.setText("Screen capture + OCR + AI dimulai...");
        }
    }
}
